import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import net.proteanit.sql.DbUtils;

public class JourneyDetails extends JFrame implements ActionListener {
    JTable table;
    JTextField pnr;
    JButton show;
    JLabel imageLabel;

    public JourneyDetails() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        JLabel lblpnr = new JLabel("PNR Details:");
        lblpnr.setFont(new Font("ARIAL", Font.PLAIN, 16));
        inputPanel.add(lblpnr);

        pnr = new JTextField(15);
        inputPanel.add(pnr);
        Color buttonColor = new Color(33, 150, 243);
        show = new JButton("Show Details");
        show.setBackground(buttonColor);
        show.setForeground(Color.WHITE);
        show.addActionListener(this);
        inputPanel.add(show);

        add(inputPanel, BorderLayout.NORTH);

        table = new JTable();
        JScrollPane jsp = new JScrollPane(table);
        jsp.setBackground(Color.WHITE);
        jsp.setBorder(BorderFactory.createTitledBorder("Reservation Details"));
        add(jsp, BorderLayout.CENTER);

        // Add an image to the bottom of the window
        ImageIcon imageIcon = new ImageIcon("airlinesystem/icons/pnr.jpg"); // Replace with the actual path to your image
        imageLabel = new JLabel(imageIcon);
        add(imageLabel, BorderLayout.SOUTH);

        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (pnr.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter a PNR number");
            return;
        }

        try {
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from reservation where PNR = '" + pnr.getText().trim() + "'");
            
            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "No Information Found");
                return;
            }
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new JourneyDetails());
    }
}